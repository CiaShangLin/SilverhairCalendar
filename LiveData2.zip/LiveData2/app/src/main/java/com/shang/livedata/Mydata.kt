package com.shang.livedata

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

class Mydata : ViewModel() {
    var currentName:MutableLiveData<String> = MutableLiveData()
    var currentTime:MutableLiveData<String> = MutableLiveData()
}