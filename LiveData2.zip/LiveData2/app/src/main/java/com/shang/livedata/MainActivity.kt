package com.shang.livedata


import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.arch.lifecycle.ViewModelStoreOwner
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    lateinit var model: Mydata
    val myRoomDatabase: MyRoomDatabase  by lazy {
        Room.databaseBuilder(this, MyRoomDatabase::class.java, MyRoomDatabase.DATABASE_NAME)
            .allowMainThreadQueries()
            .build()
    }
    val myEventDao: EventDao by lazy {
        myRoomDatabase.getEventDao()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        model = ViewModelProviders.of(this).get(Mydata::class.java)

        val nameObserver = Observer<String> {
            text.setText(it)
        }
        model.currentName.observe(this, nameObserver)

        button.setOnClickListener {
            //model.currentName.postValue(System.currentTimeMillis().toString())
            var post=myEventDao.insert(MyDataEntity().apply {
                this.currentName="1"
            })

            model.currentName.postValue(post.toString())
        }

    }
}
