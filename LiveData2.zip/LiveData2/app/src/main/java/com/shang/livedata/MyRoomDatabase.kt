package com.shang.livedata

import androidx.room.Database
import androidx.room.Entity
import androidx.room.RoomDatabase

@Database(entities = [(MyDataEntity::class)], version = 1)
abstract class MyRoomDatabase : RoomDatabase() {
    companion object {
        val DATABASE_NAME = "DATABASE_NAME"
    }

    abstract fun getEventDao(): EventDao
}