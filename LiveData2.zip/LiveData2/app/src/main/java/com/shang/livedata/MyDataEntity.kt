package com.shang.livedata

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.shang.livedata.MyDataEntity.Companion.TABLE_NAME

import java.util.*

@Entity(tableName = TABLE_NAME)
class MyDataEntity {

    companion object {
        const val TABLE_NAME:String="MY_DATA_TABLE"
        val CURRENT_NAME=""
    }

    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    @ColumnInfo(name = "currentName")
    var currentName: String = ""

    @ColumnInfo(name = "currentTime")
    var currentTime: Date = Date()
}