package com.shang.livedata

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface EventDao {
    @Query("select currentName from "+MyDataEntity.TABLE_NAME)
    fun getCurrentName():String

    @Insert
    fun insert(myDataEntity: MyDataEntity):Long
}